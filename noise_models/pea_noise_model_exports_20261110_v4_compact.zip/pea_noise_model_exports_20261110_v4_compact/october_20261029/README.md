# october_20261029: exact model used for PEA

Backend: ibm_phoenix; acquisition: 2026-10-29 UTC; 32 logical qubits.
Learning job: `dbhr4jmne4hc73bdfb30`.

| Layer | Generators | Beyond nearest neighbours in logical path | Sum of rates |
|---|---:|---:|---:|
| even | 429 | 54 | 0.0370996603869 |
| odd | 429 | 54 | 0.0376682049775 |

Rate sums are descriptive and are not total channel error probabilities.

Accepted unweighted nonnegative TRF fit: 125 iterations; rank 672, nullity 186.
The exact returned representative is retained, including tiny coefficients and boundary terms.
There is no additional gauge redistribution or diagnostic weighted refit.

October initially hit the 100-iteration limit; this is the accepted recovery with a 1,000-iteration allowance.

Read the top-level README for channel conventions, PEA scaling, adapters and limitations.
The separate readout_calibration.json describes only the measured parity, not all observables.
original/ contains unchanged source bytes; verification.json links the model to both submitted noise levels.
