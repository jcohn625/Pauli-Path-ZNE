#!/usr/bin/env python3
"""Offline example. Run from any directory; no quantum jobs or account needed."""
import argparse
from pathlib import Path
from load_model import as_ibm_maps, load_model, pauli_fidelity, sparse_terms, summary, verify_bundle


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--ibm', action='store_true', help='Also check the optional Qiskit adapter')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    check = verify_bundle(root)
    print(f"Verified {check['files_verified']} files and all original/JSON/CSV rate values.")
    for entry in check['models']:
        name = entry['model_id']
        model = load_model(root/name/'model.json')
        result = summary(model)
        print(f"\n{name}: {model['num_qubits']} qubits on {model['backend']}")
        for layer in result['layers']:
            print(f"  {layer['name']}: {layer['generators']} generators, "
                  f"sum of rates {layer['rate_sum']:.10g}, {layer['nonlocal_generators']} nonlocal terms")
        # Noise-channel eigenvalue on X at logical q0; not a circuit expectation.
        print('  Model-only even-layer fidelity on X0:', pauli_fidelity(model, 'even', 'X', [0]))
        if args.ibm:
            maps = as_ibm_maps(model)  # Unscaled: suitable for PEA's own (s-1) scaling.
            for layer in model['layers']:
                assert maps[layer['ibm_ref']].to_sparse_list() == sparse_terms(model, layer['name'])
            print('  Qiskit PauliLindbladMap roundtrip passed, without submitting anything.')


if __name__ == '__main__':
    main()
