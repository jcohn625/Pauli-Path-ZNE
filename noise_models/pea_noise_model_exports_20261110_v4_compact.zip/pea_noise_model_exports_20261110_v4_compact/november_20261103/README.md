# november_20261103: exact model used for PEA

Backend: ibm_phoenix; acquisition: 2026-11-03 UTC; 32 logical qubits.
Learning job: `dbl4re674qds73dpn700`.

| Layer | Generators | Beyond nearest neighbours in logical path | Sum of rates |
|---|---:|---:|---:|
| even | 438 | 63 | 0.0338369078308 |
| odd | 438 | 63 | 0.0332620032016 |

Rate sums are descriptive and are not total channel error probabilities.

Accepted unweighted nonnegative TRF fit: 79 iterations; rank 690, nullity 186.
The exact returned representative is retained, including tiny coefficients and boundary terms.
There is no additional gauge redistribution or diagnostic weighted refit.

November completed successfully in the live session; no unconverged fallback was used.

Read the top-level README for channel conventions, PEA scaling, adapters and limitations.
The separate readout_calibration.json describes only the measured parity, not all observables.
original/ contains unchanged source bytes; verification.json links the model to both submitted noise levels.
