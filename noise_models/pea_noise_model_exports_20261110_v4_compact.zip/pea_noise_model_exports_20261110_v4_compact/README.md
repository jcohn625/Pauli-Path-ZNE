# Compact sharing edition

This copy retains all three accepted PEA models, CSVs, qubit mappings,
readout calibrations, fit diagnostics, loader and examples from bundle v4.
Only five large November 6 per-block learning `result.json` records are
omitted. Their hashes and sizes are listed in `compact_provenance.json`;
they remain available in the unchanged full `pea_noise_model_exports_20261110_v4.zip`.
The aggregate learning result and per-block job IDs, timing metrics,
submission records and order audits remain included.

`manifest.json` describes this compact copy. Historical full-bundle
records are under `history/`; `export_provenance.json` describes the
original full v4 build. Verify and load this copy with the same commands
below. No new fitting, truncation or numerical rounding was performed.

---

# October and November hardware noise models (bundle v4)

Three **exact accepted models used for PEA on ibm_phoenix** are included:

| Folder | Acquisition (UTC) | Accepted model | Generators per layer |
| --- | --- | --- | ---: |
| `october_20261029/` | 29 October 2026 | Recovery fit after the initial iteration limit | 429 |
| `november_20261103/` | 3 November 2026 | Successful live-session fit | 438 |
| `november_20261106/` | 6 November 2026 | Successful fit of the five initial balanced learning blocks | 438 |

Every model covers 32 logical qubits and two alternating CZ layers. Its
physical-qubit path is supplied separately. The November 6 closing learning
block was diagnostic only and is excluded from the model used for PEA.
No later NNLS/weighted refits, bootstrap models or alternative representatives
have been added. The October and November 3 model folders are byte-for-byte
copies of the previous v3 export; that ZIP remains unchanged.

## Contents and offline use

Each model folder contains authoritative `model.json`, readable `rates.csv`,
separate `readout_calibration.json`, a run-specific `README.md`, provenance,
verification and unchanged selected records under `original/`.

After unpacking, use Python 3.9 or newer; no packages or IBM account are needed:

```bash
python3 load_model.py --verify-bundle .
python3 load_model.py november_20261106/model.json
python3 example.py
```

The example now visits all models listed in the bundle manifest. For reuse:

```python
from load_model import load_model, sparse_terms, pauli_fidelity
model = load_model('november_20261106/model.json')
path = model['logical_to_physical']
for pauli, sites, rate in sparse_terms(model, 'even'):
    # pauli[k] acts on logical sites[k], physical path[sites[k]].
    pass
f_x0 = pauli_fidelity(model, 'even', 'X', [0])
```

The optional `as_ibm_maps(model)` adapter returns Qiskit PauliLindbladMap
objects. Install `requirements-ibm.txt` in an isolated environment and run
`python3 example.py --ibm` to check it offline. The source experiments used
Qiskit 2.6.1. The maps use the compact 32-qubit register, not a full physical
backend register. Mapping and execution are separate responsibilities.

`as_simulator_json(model)` returns native-CZ `pauli_zne.ibm_layers.v1` input.
Import with `keep_non_nearest_neighbor=True`; the simulator importer records
the subsequent CZ-to-CNOT conversion. That simulator is not bundled.

## Rate, frame and ordering conventions

All one- and two-qubit terms are retained, including non-nearest-neighbour
logical pairs and tiny rates. The exported frame is **native CZ**, with noise
**after** the ideal layer, covering the full register including spectators:

```
D_P(rho) = P rho P - rho
E = exp(sum_P rate_P * D_P)
```

Rates are dimensionless per occurrence of the corresponding CZ layer. They
are neither probabilities nor inverse seconds. For one generator the Pauli
insertion probability is `-0.5 * expm1(-2 * rate)`. This applies to factors
of the product channel, not a mutually exclusive distribution over generators.
A sum of rates is not a total channel error probability. Learning pair depths
do not require an extra factor-of-two conversion of the supplied rates.

Logical indices are zero-based. Characters in a sparse term follow the listed
site order; Qiskit dense strings instead put logical qubit 0 at the right.
CSV includes both conventions and semicolon-separated support lists. JSON
is authoritative; preserve original precision when importing CSV elsewhere.
`pauli_fidelity` evaluates the noise-channel eigenvalue alone, not the ideal
CZ action or a target-circuit expectation.

For PEA, keep device noise separate from the actually used injection model:

```
effective rates(s) = device_rates(s) + (s - 1) * learned_used_rates
Q/ratio model rates(s) = s * learned_used_rates
```

Device=learned is an additional model assumption. At s=1 no extra noise is
injected; at s=1.5 the added rates are half the exported rates. Pass unscaled
maps to a PEA routine that already applies (s-1), to avoid double scaling.
`as_ibm_maps(model, scale=0.5)` is for constructing a half-rate map explicitly.
The same even-layer map amplified the physical singlet-preparation CZ layer.

## Acquisition and qualifications

All three accepted models use pair depths [0,1,4,18,24], nine basis settings,
50 randomizations x 64 shots per setting/depth for each layer: 288,000 shots.
November 6 splits those randomizations into five balanced blocks of ten;
its aggregate is not an additional IBM job. The five job IDs, timestamps and
aggregation hashes are retained. The later 57,600-shot diagnostic learning
block is excluded. Both PEA levels (1 and 1.5) were executed in one paired
target job, with four 50,000-shot packets per level.

Accepted unweighted nonnegative TRF fits used tolerance 1e-10 and an allowance
of 1,000 iterations: 125 iterations in October, 79 on November 3 and 104 on
November 6. Each design has nullity 186. Exact selected representatives are
retained; solver success does not establish physical-model adequacy or unique
identification of individual rates. No calibrated per-rate uncertainty is
provided. Original fit diagnostics are provenance, not certified uncertainty.

These are effective learned cycle models. Single-qubit dressing/context
effects may enter them; they are not isolated CZ-pulse error channels.
No independent single-qubit gate-error maps are supplied. Drift, context
dependence and transfer to target circuits remain scientific limitations.

TREX exports are scalar parity calibrations for Y28 Y31 after basis rotation,
not general confusion matrices or calibration of arbitrary observables.
Each before/after checkpoint used 64 x 64 shots in October and 256 x 128
in both November runs. They remain separate from gate-noise rates.

The historical `diagnostics/comparison.json` and November 4 notes concern
October 29 versus November 3 only. They do not describe November 6. The added
`diagnostics/PEA_BALANCED_RETURN_2026-11-06.md` records the balanced-run audit;
its diagnostic refits are discussed but their models are not exported.
Historical commands are provenance, not required setup instructions.

Raw shots and complete executable programs are not bundled. Source ZIPs,
consumed raw/program files, submitted maps and injected scales are hash-checked
and recorded. `history/` preserves the earlier root manifest, README and export
provenance. See `FORMAT.md` for field definitions and `manifest.json` for hashes.
