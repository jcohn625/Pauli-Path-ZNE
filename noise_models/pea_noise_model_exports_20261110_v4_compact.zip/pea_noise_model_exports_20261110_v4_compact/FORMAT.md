# Portable format: pea_noise_model.v1

UTF-8 JSON, finite numbers only. The JSON schema identifier is a project
interchange format, not an IBM API schema. Integer qubit indices are zero-based.

| Field | Definition |
|---|---|
| `schema` | Exactly `pea_noise_model.v1` |
| `model_id`, `role` | Acquisition identity and accepted-model role |
| `backend`, `acquisition_date_utc` | Device name and date of learning execution |
| `num_qubits` | Compact register width, 32 here |
| `logical_to_physical` | Element q is IBM physical qubit for logical q |
| `frame`, `placement` | `native_cz`, `after_cz` |
| `rate_convention` | `pauli_lindblad_generator_per_layer` |
| `layers` | Ordered `even`, `odd` layer records |
| `learning` | Job ID, execution timestamps, pair depths, randomizations, shots |
| `fit` | Solver settings/status, selected representative, rank/nullity |
| `scope` | Application conventions and interpretation limits |
| `software` | Source experiment's scientific-package versions |
| `provenance` | Original model identity and source hashes |

For balanced acquisitions, `learning.job_id` is null: the aggregate is not
an IBM job. `learning.job_ids` lists the five initial jobs in acquisition
order; `learning.blocks` gives their individual execution timestamps.
`learning.timestamps_utc` is the enclosing first-created/first-running to
last-finished interval, not the execution duration of one job. The 50
randomizations per setting/depth are split into five blocks of ten.
`learning.closing_diagnostic_used=false` excludes the later diagnostic block.
The original two single-job exports retain their existing fields unchanged.

Each layer has `name`, `ibm_ref`, `logical_cz_pairs`, `physical_cz_pairs` and
`terms`. Each term has source-order `term_index`, `logical_qubits`,
`physical_qubits`, `pauli_on_listed_qubits` and `rate`. Character k acts on the
k-th listed qubit. Support order is preserved exactly from the original map.
Global Pauli phases are irrelevant for the dissipator; the supplied terms use
only X/Y/Z without phase prefixes. The loader rejects duplicate generators,
invalid supports, changed CZ pairings, negative/nonfinite rates and ambiguous
placement. It does not apply a threshold to tiny coefficients.

`rates.csv` follows the same layer/term order and includes `model_id`, `layer`,
`ibm_ref`, `term_index`, `logical_qubits`, `physical_qubits`,
`pauli_on_listed_qubits`, `rate`, `qiskit_pauli_label`. Site lists are separated
by semicolons. The dense Qiskit label has exactly 32 letters, with logical q0
on the right. Numerical rate strings round-trip to the original binary64
values. The CSV is a view of JSON, not a separately fitted model.

`manifest.json` (`pea_noise_model_bundle.v1`) lists SHA-256 and byte count for
every distributed file except the manifest itself. A separate ZIP checksum
accompanies the archive. Each model's `provenance.json` records the imported
archive identity and source hashes, including checked but omitted raw/program
files. `original/` copies are unchanged. No untrusted pickle is needed.

`readout_calibration.json` (`pea_trex_parity_calibration.v1`) is a separate
scalar parity calibration with explicit support, measurement allocation,
before/after values, marginal SEs and pooled value. The supplied calibration
cannot be applied as a universal gate-noise or readout model.
