# november_20261106: exact model used for PEA

Backend: ibm_phoenix. Acquisition: 6 November 2026 UTC. 32 logical qubits.
Five initial balanced learning jobs contribute 288,000 shots; closing diagnostics are excluded.

| Layer | Generators | Nonlocal terms | Sum of rates |
| --- | ---: | ---: | ---: |
| even | 438 | 63 | 0.0375742240521 |
| odd | 438 | 63 | 0.0364234516468 |

Accepted unweighted TRF: 104 iterations; rank 690, nullity 186.
Exact accepted rates retained. No later refit or gauge redistribution.
Rate sums are not channel error probabilities. Solver success does not establish model adequacy.

The aggregate is not an IBM job. Initial job IDs:
- `dbmvced8mdtc73d8nd90`
- `dbmvu6e74qds73dt2vcg`
- `dbmvuh9kbkrc73cq99m0`
- `dbmvusl8ft8s738vkl90`
- `dbmvv7u74qds73dt30jg`

Paired target job: `dbmvvsd8ft8s738vkmc0`. All eight packets use these exact maps, with added scales 0 and 0.5.
See model.json for physical mapping; readout_calibration.json for separate observable-specific TREX.
Provenance and verification retain the source/aggregation/submission linkage.
