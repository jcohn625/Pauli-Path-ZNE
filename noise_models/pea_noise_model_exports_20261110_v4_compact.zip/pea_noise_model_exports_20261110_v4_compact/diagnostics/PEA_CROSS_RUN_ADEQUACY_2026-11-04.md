# Hardware-learning fit adequacy across runs — 4 November 2026

Question: have earlier fits to hardware data shown discrepancies as severe as
the November session? This offline comparison uses saved raw outcomes and
preserved earlier rate exports/audits. No hardware/account operation occurred.
Final Q/ratio uncertainty propagation remains deferred.

Report: `results/pea_cross_run_adequacy_20261104/report_01/report.html`.
Numerical analysis: `results/pea_cross_run_adequacy_20261104/analysis_02`.
The empty development folder analysis_01 records an aborted replay check:
one October exponent differed by 1.00698e-10, slightly beyond its original
1e-10 absolute check. The final check records the actual differences and bounds
both absolute discrepancy (1e-8) and discrepancy relative to sampling SE (1e-4).
The observed discrepancy is only 3.75936e-7 SE; original data were not edited.

## Directly comparable evidence

Both October 29 and November 3 runs use ibm_phoenix, 32 qubits, two alternating
CZ layer types, 50 randomizations × 64 shots, and pair depths [0,1,4,18,24].
Paths and selected hardware graphs differ. There are 858 October decay rows
and 876 November rows, each with exactly 186 duplicate-row pairs.

| Diagnostic | October 29 | November 3 |
|---|---:|---:|
| Pairs with approximate simultaneous 95% bands excluding zero | 3 / 186 | 8 / 186 |
| Largest absolute pair difference / bootstrap SD | 5.184 | 9.702 |
| Largest absolute pair difference in b | 0.00304224 | 0.01113391 |
| Unweighted NNLS residual RMS / quoted SE | 0.799371 | 1.532677 |
| Unweighted NNLS maximum absolute residual / quoted SE | 4.28132 | 14.06938 |
| Unweighted NNLS residuals above 5 quoted SE | 0 | 15 |
| Weighted NNLS residual RMS / quoted SE | 0.656300 | 1.054614 |
| Weighted NNLS maximum absolute residual / quoted SE | 3.98414 | 8.94405 |
| Individual exponential fits: median reduced chi-square | 0.929408 | 0.967463 |
| Individual exponential fits: 95th percentile reduced chi-square | 3.54960 | 3.60408 |

Here b is the exponent in a exp(-b d), d counts CZ-layer pairs, and quoted SE
refers to marginal learning errors. Normalized residual RMS is not reduced
chi-square. Pair ratios are not exact Gaussian significances. Individual
curve fits are similarly good; November has worse joint-model consistency.
October's global normalized residual RMS below one does not validate every
pair constraint.

## Same paired-constraint procedure

The October analysis rebuilds the parity cache from raw measurements and the
saved path/sequence relations. Refit b differs from the saved value by at most
1.00698e-10, sigma by 1.47020e-12. All 858 base fits succeed without issues.
All 372 rows appearing in the 186 paired constraints are refitted under 200
whole-randomization bootstrap draws, stratified by setting/depth. Shared
observables use the same selected records, preserving their correlations;
shots within a randomization are not resampled again. Non-paired rows are
intentionally not bootstrapped. All attempts and selections are retained.

All 200 October batches succeed without warnings, boundaries or fallbacks.
Seed: 20261106. November reuses its existing 200 replicates, reproducing the
previous paired-contrast statistics to 1e-10. Simultaneous bands use the 95th
percentile of the maximum absolute centered, standardized pair contrast across
all 186 pairs within each run. Cutoffs: 3.55150 October; 3.52408 November.

October flagged pairs:

| Rows | Layer | Physical support | Difference / bootstrap SD |
|---|---|---|---:|
| 4 / 99 | even | 39–49 | -5.184 |
| 782 / 784 | odd | 82–83 | 5.087 |
| 529 / 533 | odd | 49–59 | -3.656 |

The first two are clear relative to this procedure's cutoff; the third is
close. A fourth contrast, rows 430/526 on 49–59, is just below it (3.482).
Finite-bootstrap sensitivity is material near the threshold: first/last
100-replicate halves flag 3/4 pairs, respectively. The two strongest contrasts
remain approximately 5.0–5.3 in both halves. The full 200-replicate result is
reported without promoting it to an exact count of physical model violations.
November's eight flagged contrasts range from 6.43 to 9.70.

The two experiments use different paths, and physical qubit 76 is absent from
the October and screened September paths. This is not a measurement of
temporal worsening on a fixed device subset. The same diagnostic failure
does not establish the same physical cause.

## Older September evidence

The three screened September runs have preserved native-model exports which
pass the repository baseline hashes. Their total-rate sample SD / mean is
2.35% (even) and 4.13% (odd). Odd-layer Z99 is 0.00024, 0.00107 and 0.00166.
These are differences between fitted models; they are not within-fit residuals.
The earlier audit explicitly records no raw counts, decay residuals or
parameter uncertainties. Original Downloads archives are currently absent.
Consequently, these fits cannot be declared consistent with the current
paired-cycle tests, nor assigned comparable statistical discrepancy levels.

The preserved audit of the initial unscreened September run reports qubit 17
readout error near 49.9%, adjacent CZ calibration entries equal to 1, and
fitted rates as large as 5.20379. These were severe hardware/fit-validity
warnings, of a different type from a demonstrated decay-model residual.
Without the original decay data they cannot distinguish strong physical noise,
uninformative measurement and fitting instability. Calibration entries equal
to 1 were not established to be literal error probabilities rather than
failed-calibration/sentinel values. The initial audit is used as preserved
evidence, not as a new reanalysis of unavailable raw data.

## Solver status and provenance

October's original fit exhausted 100 iterations. Its accepted recovery
converged in 125 iterations. Independent NNLS reproduces the recovered
predictions within 8.68697e-8, so the solver interruption is separate from
physical-model adequacy. November's analogous prediction difference is
2.70420e-7. No fitted rate vector was substituted into the actual PEA result.

All 137 October checksum-listed files pass and all input hashes are unchanged.
Prior November files, source/helper/payload readers and source snapshots are
hashed. Historical report inputs and all three September rate exports are
hashed separately in the report folder. Numerical-library threads are one;
network connections are blocked during analysis. Each bootstrap uses the full
record-level correlation structure available for that run; different runs do
not share synthetic shot realizations. Failures would be retained and block
inference, rather than being silently removed.

## Reproduction

Use new output directories:

```bash
hardware/pea_pilot/.venv/bin/python tools/compare_hardware_learning_fits.py \
  --october-run results/pea_pilot_hardware_analysis_20261030/imported/pea_pilot_v2_completed_results/pilot_s1_local_001 \
  --november-analysis results/pea_learning_diagnostics_20261104/analysis_01 \
  --output results/pea_cross_run_adequacy_20261104/reproduction_001 --bootstrap 200

hardware/pea_pilot/.venv/bin/python tools/render_hardware_fit_comparison.py \
  --analysis results/pea_cross_run_adequacy_20261104/reproduction_001 \
  --output results/pea_cross_run_adequacy_20261104/reproduction_report_001 \
  --september-audit-dir '/Users/piotrczarnik/Documents/Codex/2026-08-11/d/outputs'

hardware/pea_pilot/.venv/bin/python -m unittest \
  tools.test_hardware_fit_comparison tools.test_pea_learning_diagnostics
```

Ten tests pass: three new comparison tests plus seven parity/resampling/fit
tests. New tests verify cancellation of shared-record fluctuations, retention
of failed paired draws, and rejection of unsupported row multiplicities.
Source hashes, report links, native September hashes and numerical reproduction
checks pass. Generated outputs remain outside Git; source and this record are
committed. No push is performed.
