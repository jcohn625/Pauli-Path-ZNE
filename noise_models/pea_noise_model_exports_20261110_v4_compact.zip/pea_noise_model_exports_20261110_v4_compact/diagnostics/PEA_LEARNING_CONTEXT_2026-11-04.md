# PEA learning circuits, basis context and acquisition timing — 4 November 2026

Requested follow-up: inspect the discrepant paired circuits, basis operations
and noise-model assumptions. The user explicitly deferred uncertainty
propagation through Q and ratio. No IBM job, account request, replacement
injection model or simulator campaign was performed.

Report: `results/pea_learning_context_20261104/report_02/report.html`.
Numerical evidence: `results/pea_learning_context_20261104/audit_02`.
Four figures are supplied as PNG and vector PDF. Development outputs
`audit_01` and `report_01` are retained separately. The final audit adds explicit
single-qubit path-sign checks, conditional fit-status tracking and hashes of
the prior numerical inputs; its scientific results agree with audit_01.

## Provenance

The input remains the preserved extraction of `pea_session_v3_return.zip`
(SHA256 `d12f996d02713b1f8f816ecd77980221125b6995449bb81b37b953549392c1f5`).
All 819 imported files match the previous analysis's hashes before and after
the audit. All 54 issued package payloads match their manifest. Only verified
issued readers were imported; returned scripts were not run. Python network
connections were blocked throughout the audit. Numerical-library threads
were set to one. The source snapshot, helper and selected SDK source hashes,
software versions and hashes of all prior numerical inputs used by the audit
are saved in summary.json. New local twirl seed: 20261105.

## Native circuit checks

Three newly seeded samples were drawn from every saved setting: two CZ layer
types, five pair depths [0,1,4,18,24], nine basis configurations (270 circuits).
The audit remaps native physical qubits to the saved logical path, checks the
classical measurement map, rounds float32 RZ angles to Clifford angles,
propagates measured Paulis backwards through native gates, and applies both
sampled measurement flips and SDK path signs.

| Check | Passed comparisons |
|---|---:|
| Single-qubit paths need no additional sign after readout flips | 2,880 |
| Corrected ideal path expectation is +1 | 18,900 |
| CZ layer count equals twice pair depth | 270 |
| After-CZ Pauli agrees with the SDK path at each occurrence | 355,320 |
| Independently reconstructed native noise-design coefficients equal saved A | 3,780 |
| Separate stabilizer expectation agrees at depth one | 1,260 |

There are zero failures. Maximum RZ angle rounding is 8.742278e-8 rad;
the largest conservative sum-of-angle-errors expectation bound is 1.438979e-4.
The audit is of saved executable definitions with new draws. Exact IBM twirl
parameters and a complete pulse-level execution record are absent, so it is
not a replay or certification of actual server-side pulse execution.

The serialized templates contain RZ–SX–RZ–SX–RZ dressing, with 2d+1 dressing
layers at pair depth d: 64(2d+1) SX instructions over 32 qubits. Depths 0, 1 and
24 contain 64, 192 and 3,136 SX instructions respectively. Interior injected
local-Clifford arguments are identity; endpoint basis choices vary. These are
instruction counts, not measured pulse counts. The effective fitted noise
cannot automatically be identified with isolated physical CZ noise.

## New context-resolved evidence

The 576 conditional single-qubit decay fits all succeed without warnings,
fallbacks or boundary flags. Physical 76 (logical 21) shows the dominant
context differences in both layer types. Neighbours are physical 75 and 66.
The following b values fit a exp(-b d), where d counts pairs of CZ layers:

| Layer | Own basis on 76 | Neighbours X / early | Neighbours Y / middle | Neighbours Z / late |
|---|---|---:|---:|---:|
| even | X | 0.015005 ± 0.001087 | 0.003858 ± 0.000263 | 0.004238 ± 0.000285 |
| even | Y | 0.013699 ± 0.000951 | 0.004483 ± 0.000326 | 0.004255 ± 0.000285 |
| even | Z | 0.003050 ± 0.000267 | 0.002915 ± 0.000240 | 0.002884 ± 0.000245 |
| odd | X | 0.013719 ± 0.000993 | 0.003816 ± 0.000293 | 0.003586 ± 0.000285 |
| odd | Y | 0.013225 ± 0.001033 | 0.003858 ± 0.000286 | 0.003503 ± 0.000280 |
| odd | Z | 0.003259 ± 0.000215 | 0.002450 ± 0.000238 | 0.002887 ± 0.000245 |

Errors are SDK marginal fit SE, not uncertainty including drift or model
misspecification. These are decay exponents, not individual generator rates.
Each conditional curve uses 50 randomizations × 64 shots per depth. Its own
basis stays fixed while the alternating basis pattern changes on other
qubits, so "neighbours" is a context label, not a proven localized cause.

The four X/Y heterogeneity statistics on qubit 76 range from 83.17 to 99.70;
the largest other qubit/axis statistic is 10.31. They are exploratory marginal
diagnostics, not calibrated family-wide significance statistics. Recombining
the conditional raw clusters exactly reproduces the prior SDK-pooled means
and standard errors for implicated single-qubit rows 64,65,499,500 to 1e-14.

## Time/basis confounding

Learning job: `dbl4re674qds73dpn700`. The five returned acquisition chunks
span 2026-11-03 21:20:40.716471–21:20:50.934157 UTC (10.217686 s).
The SDK sequential item/record mapping assigns:

| Chunk | Configurations | Bases on logical 20,21,22 | Seconds from first chunk start |
|---|---|---|---|
| 0 | 0 | XXX | 0.000–2.144 |
| 1 | 1,2 | XYX, XZX | 2.293–4.642 |
| 2 | 3,4 | YXY, YYY | 4.703–6.922 |
| 3 | 5,6 | YZY, ZXZ | 6.934–8.699 |
| 4 | 7,8 | ZYZ, ZZZ | 8.776–10.218 |

Every chunk contains records from all ten layer/depth items. The records do
not reveal exact circuit timestamps or ordering within each chunk. Early
settings 0 and 1 have large X/Y decay on 76 and neighbours in X; later settings
change both context and time. Z in setting 2 shares chunk 1 with the early Y
probe and is affected much less. A phase-noise change is compatible with the
pattern but is not established as its cause.

The four large two-qubit contrasts compare early and later contexts. The
four smaller contrasts compare pooled single-qubit paths against correlated
paths measured in a late context. The report gives each physical Pauli cycle
and the configuration mapping. This is consistent with a common context/time
effect; it is not a causal decomposition of the discrepancy.

## Assumptions and depth checks

For the same stationary Pauli channel on each occurrence of an involutory CZ
layer C, the two-cycle product f(P)f(CPC) is invariant under swapping its
starting member. This remains true for arbitrary Pauli support, not just the
chosen two-local model. Weighting, signed rates, gauge choice, consistently
placing noise before instead of after C, or adding generator support cannot
remove that equality. Depth-independent multiplicative SPAM and a consistent
effective dressed channel are assumptions; time/context dependence, residual
coherence, leakage or depth-dependent preparation/measurement effects can
invalidate the simple description.

This interpretation follows the Pauli-trajectory formalism in
[IBM's documentation](https://quantum.cloud.ibm.com/docs/en/addons/qiskit-noise-learning/guides/formalism)
and the treatment of single-qubit noise as part of a dressed cycle in
[Chen et al. (2023)](https://pmc.ncbi.nlm.nih.gov/articles/PMC9813261/).

Because depth zero merges endpoint basis operations, all 16 implicated rows
were refitted without it. A second sensitivity check removes depth 24. All
eight paired differences keep their signs and pointwise 95% bootstrap
percentile intervals exclude zero under both alternatives. Rows 316/320 have
differences 0.011133907 (all depths), 0.009972642 (no zero depth), and
0.011914587 (no depth 24). These selected, pointwise sensitivity checks do not
replace the previous simultaneous check across 186 pairs.

The same 200 whole-randomization bootstrap selections were retained, including
cross-observable correlations. All 600 batches of 16 decay fits succeed without
issues. The all-depth draws reproduce previous b samples to 1e-10. Thus the
endpoint or deepest point alone does not explain the inconsistency.

## Next experiment and scope limits

The proposed validation should distribute all nine basis settings across
several short balanced blocks, counterbalancing/randomizing order within
blocks while balancing depths and layer types. Verify returned chunk/record
mapping: simply changing the configuration list may leave server batching
intact. Keep the same path and CZ layer structure, retain qubit 76's Z probe
and nearby-qubit controls, and save randomization seeds or bound parameters
where supported, timing, mapping and calibration metadata. An effect following
time across permutations would support a transient; an effect following a
particular context at matched times would motivate dressing/context tests.
No follow-up hardware execution is included in this task.

The actual injected model stays fixed. Later device sensitivity must use
device(s) + (s-1)*learned_used, not retroactively alter amplification rates.
More TREX shots alone do not repair gate-learning decay inconsistencies.
Q/ratio estimates and their uncertainty are explicitly deferred.

## Reproduction and verification

Use new output folders in the pinned pilot environment:

```bash
hardware/pea_pilot/.venv/bin/python tools/audit_pea_learning_context.py \
  --return-root results/pea_session_v3_analysis_20261104/imported/pea_session_v3_return \
  --issued results/pea_pilot_collaborator_v3_20261103/pea_pilot_collaborator_v3 \
  --prior results/pea_learning_diagnostics_20261104/analysis_01 \
  --output results/pea_learning_context_20261104/reproduction_001 --samples 3

hardware/pea_pilot/.venv/bin/python tools/render_pea_learning_context.py \
  --audit results/pea_learning_context_20261104/reproduction_001 \
  --output results/pea_learning_context_20261104/reproduction_report_001

hardware/pea_pilot/.venv/bin/python -m unittest \
  tools.test_pea_learning_context tools.test_pea_learning_diagnostics
```

All 13 tests pass. Six new tests cover CZ phase signs and arbitrary-support
cycle equalities, native propagation versus independent dense statevector,
necessary readout correction, physical/classical remapping, non-Clifford
rejection and split-setting chunk brackets. Independent saved-data checks
confirm source hashes, unchanged prior inputs, identical all-depth bootstrap
draws, raw-to-pooled means/SE, all 24 interval signs and local report links.
All four scientific figures were visually inspected. `git diff --check` passes.
