# Balanced PEA v4.1 hardware return — 6 November 2026

Input archive:
`/Users/piotrczarnik/Downloads/pea_session_v4_1_return_2026-11-06.zip`

SHA-256: `ea131aab0406449a44fa629c149c5e58eef363f7e8d8df986722eb5ef340a068`.
All 2,486 manifest payloads were streamed and checked, including historical
fixtures and large rehearsal files not duplicated during extraction. All 73
issued package files match their manifest and the local v4.1 release from
commit `3d3ad46588d05f82d0201231746171f48364d4f3`. Returned instructions and
scripts were not executed. Network access was blocked in the analysis scripts.

Generated evidence root:
`results/pea_session_v4_1_analysis_20261106/` (ignored, outside Git).

- `imported/`: preserved returned bytes, with selective extraction recorded in
  `import_validation.json`.
- `audit_07/`: successful final audit, 1,880 checks; earlier attempts retain
  analysis-development diagnostics, not evidence of hardware failure.
- `transport_01/`: independent original Executor response decoding; every raw,
  flip and sign array agrees for all nine jobs.
- `diagnostics_01/`: two 200-replicate paired-context bootstraps and two
  2,000-permutation closing-checkpoint tests, saved draws and failure records.
- `window_alignment.json`: exact server-index correspondence across all 90
  settings per window, including reordered window indices.
- `report_final/`: HTML report, PNG/PDF figures, JSON summaries and provenance.

## Numerical and execution checks

Nine jobs DONE, 811,136 shots, original 32-qubit Phoenix path. All frozen
scientific input hashes and source hashes passed. No STOP, cancellation or
workflow/monitoring failure was recorded. The fresh injected model derives
only from the five initial learning blocks, with no closing-checkpoint data.
Explicit target injection scales are zero and 0.5, with 200,000 shots each.
Preparation is included in the 115 injected layers / 1,783 CZ gates.

The SDK raw-data linear-system replay differs in b by at most 8.34e-13.
Independent parity-cache aggregation changes summation order: its maximum
decay difference is 1.46e-10, only 3.66e-7 of reported SD. The declared cache
replay tolerances are 1e-9 absolute **and** 1e-5 reported SD. The independent
NNLS predictions differ from the accepted TRF fit by at most 1.99e-8. All
6,000 target/TREX bootstrap draws reproduce exactly. Original run files
remained byte-identical after the audit.

Session accounting: 368 seconds in both saved post-closure usage readings;
367.572 seconds active, 258.919 seconds in job RUNNING intervals, 9.589 seconds
for the local fit and 99.064 seconds of other active time. Summed job usage
is 54 seconds. These accounting categories are not interchangeable. There
was no inactive interval. No live account or invoice verification was done.

Paired-context maximum: 2.541 bootstrap SD versus simultaneous threshold
3.543; zero of 186 pairs flagged. Whole-window sensitivity: maximum 2.654,
threshold 3.477, also zero flagged. Closing checkpoint global p=0.29235 with
within-setting permutations and 0.33133 with whole-window permutations;
zero of 4,380 cells flagged in either case. Both schemes retain correlations
between observables from shared raw records. Neither establishes equivalence
or attributes the earlier run's inconsistency exclusively to acquisition time.

Used unweighted joint-fit residual RMS/max: 0.753/5.780 reported SD; diagnostic
weighted NNLS: 0.569/2.063. Rank 690/876, nullity 186. Twenty-two individual
decays have reduced chi-square above five. No physical-model validation,
learned-rate propagation, tensor convergence or final Q/ratio claim is made.

## Reproduce

Use the pinned environment `hardware/pea_pilot/.venv/bin/python`; numerical
library thread limits are set to one by the analysis modules. Choose new
output directories, never overwrite the preserved inputs.

```sh
hardware/pea_pilot/.venv/bin/python tools/analyze_pea_balanced_return.py \
  --run results/pea_session_v4_1_analysis_20261106/imported/results/balanced_s1_v4_1_001 \
  --output NEW_ROOT/audit
hardware/pea_pilot/.venv/bin/python tools/analyze_pea_balanced_return.py \
  --run results/pea_session_v4_1_analysis_20261106/imported/results/balanced_s1_v4_1_001 \
  --output NEW_ROOT/transport_01 --transport-only
hardware/pea_pilot/.venv/bin/python tools/analyze_pea_balanced_diagnostics.py \
  --audit NEW_ROOT/audit --output NEW_ROOT/diagnostics \
  --bootstrap 200 --permutations 2000 --seed 20261106
hardware/pea_pilot/.venv/bin/python tools/render_pea_balanced_report.py \
  --audit NEW_ROOT/audit --diagnostics NEW_ROOT/diagnostics \
  --output NEW_ROOT/report
hardware/pea_pilot/.venv/bin/python -m unittest tools.test_pea_balanced_analysis -v
```

Rendering the delivered report also records the original import validation,
supplementary window alignment and prior October/November comparisons.
The six regression tests cover timestamp timezone handling, closing sample
counts and metadata, circuit UUID normalization without losing gate/wire
changes, block/window resampling, reordered acquisition-window alignment,
and a stationary versus shifted synthetic permutation test.
