# October and November hardware noise models

This bundle contains the **exact accepted models used for PEA** on
`ibm_phoenix` on 29 October and 3 November 2026. There are 32 logical qubits,
two alternating CZ layers and a different physical path in each experiment.
The October model is the accepted recovery after the original optimizer hit
its iteration limit. The November model is the successful live-session fit.
Neither model has been replaced by a later weighted or alternative-gauge fit.

Each folder, `october_20261029/` and `november_20261103/`, contains:

| File | Purpose |
|---|---|
| `model.json` | Authoritative portable model, mapping, CZ pairs, rates and conventions |
| `rates.csv` | One row per generator; all source precision and terms preserved |
| `readout_calibration.json` | Separate observable-specific TREX calibration |
| `README.md` | Run-specific counts and fitting details |
| `provenance.json` | Original input hashes and inclusion/omission record |
| `verification.json` | Checks linking these rates to submitted PEA programs |
| `original/` | Unchanged original model, plan, configuration and selected fit/measurement records |

October has 429 generators per layer (858 total); November has 438 per layer
(876 total). The rates include one-qubit and two-qubit terms, including pairs
that are non-nearest-neighbours along the logical chain. No generators or
small rates were removed. A channel's sum of rates is not its error probability.

## Read and verify without installing packages

Use Python 3.9 or newer. From the unpacked bundle directory:

```bash
python3 load_model.py --verify-bundle .
python3 load_model.py november_20261103/model.json
python3 example.py
```

These commands are offline. They read the exports, verify hashes and exact
agreement between the original maps, JSON and CSV, and print brief summaries.
They do not require an IBM account or submit jobs. All executable helper code
is included; no original project checkout or source datasets are needed.

To use the data in your code (with this directory on Python's import path):

```python
from load_model import load_model, sparse_terms, pauli_fidelity

model = load_model("november_20261103/model.json")
path = model["logical_to_physical"]
for pauli, sites, rate in sparse_terms(model, "even"):
    # pauli[k] acts on logical site sites[k], physical qubit path[sites[k]].
    pass
f_x0 = pauli_fidelity(model, "even", "X", [0])
```

`pauli_fidelity` returns the eigenvalue of the noise channel on a specified
Pauli. It is not a circuit expectation and does not include the ideal CZ
layer's action. Logical qubit numbers are zero-based. In a sparse term
`("XZ", [0, 3], rate)`, X acts on logical 0 and Z on logical 3. This is
different from Qiskit's dense string ordering, where logical qubit 0 is the
rightmost character. `rates.csv` includes that dense label for convenience;
semicolon-separated site lists keep each support in one CSV cell.

## Mathematical convention and reuse

For each layer, the exported coefficients define

```
D_P(rho) = P rho P - rho
E = exp(sum_P rate_P * D_P)
```

Rates are dimensionless per occurrence of that CZ layer. They are not error
probabilities or inverse seconds. The corresponding single-generator Pauli
insertion probability is `p = -0.5 * expm1(-2 * rate)`. This formula applies
to each factor in the product channel, not to a mutually exclusive list of
all generators. Do not divide or multiply the exported rates by two merely
because the learning depths counted pairs of CZ layers.

The supplied frame is **native CZ**, and the noise is placed **after** the
corresponding ideal layer. A model covers the full 32-qubit register, including
spectators. It is an effective learned cycle model: single-qubit dressing or
context effects can enter it, so it must not automatically be interpreted as
an isolated CZ-pulse error model. No independent single-qubit gate channels
or universal readout error matrix are provided.

In PEA, distinguish the measured device from the learned injection model:

```
effective rates(s) = device_rates(s) + (s - 1) * learned_used_rates
Q/ratio model rates(s) = s * learned_used_rates
```

The first expression is a Pauli-model description, conditional on its
assumptions. At s=1 no extra noise is injected; at s=1.5 the added channel
has half the exported rates. Assuming device=learned is a further modeling
choice, not a hardware fact established by this export. The same even-layer
map was also used for amplification of the physical singlet-preparation CZ.

## Optional IBM/Qiskit adapter

The core reader needs no packages. To use the optional adapter in an isolated
environment, install `requirements-ibm.txt`, then run `python example.py --ibm`.
The adapter was tested with Qiskit 2.6.1, the version used in both runs.

```python
from load_model import as_ibm_maps
maps = as_ibm_maps(model)  # Full learned rates, keyed by the original IBM refs.
```

These maps use the compact 32-qubit logical register. The physical path is
supplied separately in `logical_to_physical`; the adapter does not construct
a 120-qubit physical-register map or a complete PEA execution workflow.
When an IBM PEA routine applies `(s-1)` itself, pass the unscaled maps above.
For a manually constructed extra channel, `as_ibm_maps(model, scale=0.5)`
provides half-rates; do not also apply the PEA scaling a second time.

`as_simulator_json(model)` provides the repository's existing
`pauli_zne.ibm_layers.v1` native-CZ input. Import it with
`keep_non_nearest_neighbor=True`; the repository importer records the
subsequent CZ-to-CNOT frame conversion. That optional simulator is not bundled.
The primary exports themselves perform no frame conversion or truncation.

## Calibration and scientific limitations

Learning used one pass, pair depths [0,1,4,18,24], nine basis settings and
50 randomizations x 64 shots per setting/depth for each of the two layers
(288,000 shots). Nonnegative least squares used SciPy's TRF solver with
tolerance 1e-10 and a 1,000-iteration allowance in the accepted fits.
October converged in 125 iterations and November in 79.

Both designs have nullity 186. The exports retain the exact selected
nonnegative representative; no unique identification of every individual
rate or per-rate uncertainty is claimed. Diagnostic refits and bootstrap
model ensembles are not included as alternative physical models here.

The same approximate simultaneous bootstrap comparison flagged 3/186 paired
constraints in October and 8/186 in November. Largest differences divided by
bootstrap SD were 5.18 and 9.70. These are model-consistency diagnostics, not
exact Gaussian significances. November's dominant qubit-76 X/Y context
dependence is confounded with acquisition time. Different physical paths
prevent interpreting the comparison as temporal degradation of one fixed
qubit subset. The model may omit drift or context-dependent behavior.

The separate TREX files contain scalar parity calibrations for the measured
Y28 Y31 observable after basis rotation. October used 64 x 64 shots per
checkpoint, November 256 x 128; both have before/after checkpoints. These
scalars are not a confusion matrix or calibration for arbitrary observables.

`diagnostics/comparison.json` and the preserved audit notes provide the
comparison details. Historical paths/commands in those notes refer to the
original project and are provenance, not required setup instructions.
Raw shots, complete executable programs and pulse records are not bundled;
their relevant hashes and the export's injection checks are retained.

References for conventions:
- https://quantum.cloud.ibm.com/docs/en/api/qiskit-noise-learning/generated/models-pauli-lindblad-model
- https://quantum.cloud.ibm.com/docs/en/guides/noise-learning
- https://pmc.ncbi.nlm.nih.gov/articles/PMC9813261/

See `FORMAT.md` for the versioned field definitions. JSON is authoritative:
spreadsheet applications may round displayed CSV numbers, so preserve the
original files and use the loader for numerical reuse.
