#!/usr/bin/env python3
"""Portable Pauli-Lindblad model reader. Core operations use only Python 3.9+."""
import argparse
import csv
import hashlib
import json
import math
from pathlib import Path

SCHEMA = 'pea_noise_model.v1'
FIELDS = ['model_id', 'layer', 'ibm_ref', 'term_index', 'logical_qubits',
          'physical_qubits', 'pauli_on_listed_qubits', 'rate', 'qiskit_pauli_label']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dense_label(term, n, qiskit_order=True):
    """Sparse characters follow listed sites; Qiskit dense labels reverse q0..qN."""
    word = ['I'] * n
    for p, q in zip(term['pauli_on_listed_qubits'], term['logical_qubits']):
        word[q] = p
    return ''.join(reversed(word) if qiskit_order else word)


def validate(model):
    require(model.get('schema') == SCHEMA, 'Unsupported model schema')
    require(model['rate_convention'] == 'pauli_lindblad_generator_per_layer', 'Rate convention')
    require(model['frame'] == 'native_cz' and model['placement'] == 'after_cz', 'Frame/placement')
    path, n = model['logical_to_physical'], model['num_qubits']
    require(type(n) is int and n >= 4 and n % 2 == 0 and len(path) == n, 'Model width')
    require(all(type(q) is int and q >= 0 for q in path) and len(set(path)) == n, 'Qubit map')
    require([x['name'] for x in model['layers']] == ['even', 'odd'], 'Layer ordering')
    require(len({x['ibm_ref'] for x in model['layers']}) == 2, 'Duplicate layer reference')
    for parity, layer in enumerate(model['layers']):
        edges = [[q, q + 1] for q in range(parity, n - 1, 2)]
        require(layer['logical_cz_pairs'] == edges, 'CZ layer mismatch')
        require(layer['physical_cz_pairs'] == [[path[q] for q in e] for e in edges], 'Physical CZ map')
        require(layer['terms'], 'Empty layer')
        seen = set()
        for i, term in enumerate(layer['terms']):
            sites, chars, rate = term['logical_qubits'], term['pauli_on_listed_qubits'], term['rate']
            require(term['term_index'] == i, 'Changed source term order')
            require(len(sites) in (1, 2) and len(sites) == len(chars) and len(set(sites)) == len(sites), 'Pauli support')
            require(all(type(q) is int and 0 <= q < n for q in sites) and all(c in 'XYZ' for c in chars), 'Invalid Pauli')
            require(term['physical_qubits'] == [path[q] for q in sites], 'Term physical mapping')
            require(type(rate) in (float, int) and math.isfinite(rate) and rate >= 0, 'Invalid rate')
            key = tuple(sorted(zip(sites, chars)))
            require(key not in seen, 'Duplicate generator')
            seen.add(key)
    return model


def load_model(path):
    """Read and structurally validate; use verify_bundle for file integrity too."""
    return validate(read(path))


def sparse_terms(model, layer_name):
    layer = next(x for x in model['layers'] if x['name'] == layer_name)
    return [(t['pauli_on_listed_qubits'], t['logical_qubits'], t['rate']) for t in layer['terms']]


def pauli_fidelity(model, layer_name, pauli, logical_qubits, scale=1.):
    """Eigenvalue of the noise channel alone on a Pauli (not the ideal CZ layer).

    Terms anticommuting with the probe contribute exp(-2*scale*rate).
    This evaluates a model prediction, not a measurement or adequacy test.
    """
    require(math.isfinite(scale) and scale >= 0, 'Scale must be finite and nonnegative')
    require(len(pauli) == len(logical_qubits) and len(set(logical_qubits)) == len(logical_qubits), 'Probe support')
    require(all(c in 'XYZ' for c in pauli) and all(type(q) is int and 0 <= q < model['num_qubits'] for q in logical_qubits), 'Probe Pauli')
    probe = dict(zip(logical_qubits, pauli))
    rates = []
    for chars, sites, rate in sparse_terms(model, layer_name):
        anticommutes = sum(q in probe and probe[q] != p for q, p in zip(sites, chars)) % 2
        if anticommutes:
            rates.append(rate)
    return math.exp(-2 * scale * math.fsum(rates))


def as_ibm_maps(model, scale=1.):
    """Optional Qiskit adapter; no account, Runtime service or hardware access.

    Default scale=1 returns the learned maps. For an added PEA channel at noise
    factor s, scale=s-1. The actual device channel is a separate object.
    """
    require(math.isfinite(scale) and scale >= 0, 'Scale must be finite and nonnegative')
    from qiskit.quantum_info import PauliLindbladMap
    return {layer['ibm_ref']: PauliLindbladMap.from_sparse_list(
        [(p, qs, r * scale) for p, qs, r in sparse_terms(model, layer['name'])],
        num_qubits=model['num_qubits']) for layer in model['layers']}


def as_simulator_json(model):
    """Native-CZ input for pauli_zne.ibm_noise; no frame conversion or truncation.

    Import with keep_non_nearest_neighbor=True. That importer separately records
    its target-H CZ-to-CNOT conversion and preserves the after-layer placement.
    """
    learning = model['learning']
    identity = (dict(learning_job_ids=learning['job_ids']) if 'job_ids' in learning
                else dict(learning_job_id=learning['job_id']))
    return dict(schema='pauli_zne.ibm_layers.v1',
        logical_to_physical=model['logical_to_physical'], rate_convention='pauli_lindblad_generator',
        pauli_label_order='qiskit', placement='after',
        layers=[dict(id=x['ibm_ref'], qubits=model['logical_to_physical'],
            gates=[dict(name='cz', qubits=e) for e in x['physical_cz_pairs']],
            generators=[dense_label(t, model['num_qubits']) for t in x['terms']],
            rates=[t['rate'] for t in x['terms']]) for x in model['layers']],
        metadata=dict(source_placement='after_cz', **identity))


def csv_rows(model):
    for layer in model['layers']:
        for term in layer['terms']:
            yield dict(model_id=model['model_id'], layer=layer['name'], ibm_ref=layer['ibm_ref'],
                term_index=str(term['term_index']),
                logical_qubits=';'.join(map(str, term['logical_qubits'])),
                physical_qubits=';'.join(map(str, term['physical_qubits'])),
                pauli_on_listed_qubits=term['pauli_on_listed_qubits'], rate=repr(term['rate']),
                qiskit_pauli_label=dense_label(term, model['num_qubits']))


def summary(model):
    return dict(model_id=model['model_id'], backend=model['backend'],
        date=model['acquisition_date_utc'], num_qubits=model['num_qubits'],
        layers=[dict(name=x['name'], generators=len(x['terms']),
            nonlocal_generators=sum(len(t['logical_qubits']) == 2 and
                abs(t['logical_qubits'][1] - t['logical_qubits'][0]) > 1 for t in x['terms']),
            rate_sum=math.fsum(t['rate'] for t in x['terms']),
            minimum_rate=min(t['rate'] for t in x['terms'])) for x in model['layers']])


def verify_bundle(root):
    root = Path(root).resolve()
    manifest = read(root / 'manifest.json')
    require(manifest['schema'] == 'pea_noise_model_bundle.v1', 'Bundle schema')
    for name, record in manifest['files'].items():
        path = (root / name).resolve()
        require(root in path.parents, 'Manifest path escapes bundle')
        require(path.stat().st_size == record['bytes'] and sha(path) == record['sha256'], 'File changed: ' + name)
    checked = []
    for name in manifest['models']:
        folder = root / name
        model = load_model(folder / 'model.json')
        with (folder / 'rates.csv').open(newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            require(reader.fieldnames == FIELDS and list(reader) == list(csv_rows(model)), 'CSV/JSON disagreement')
        original = read(folder / 'original/learned_model.json')
        require(model['logical_to_physical'] == original['physical_path'] and
                model['placement'] == original['placement'], 'Original mapping/placement')
        for layer in model['layers']:
            want = original['maps'][layer['ibm_ref']]['__value__']['paulis']
            got = [list(t) for t in sparse_terms(model, layer['name'])]
            require(got == want, 'Original rates/order changed')
        checked.append(summary(model))
    return dict(passed=True, files_verified=len(manifest['files']), models=checked)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('model', nargs='?', type=Path)
    parser.add_argument('--verify-bundle', type=Path)
    args = parser.parse_args()
    if args.verify_bundle:
        result = verify_bundle(args.verify_bundle)
    elif args.model:
        result = summary(load_model(args.model))
    else:
        parser.error('Supply model.json or --verify-bundle DIRECTORY')
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
